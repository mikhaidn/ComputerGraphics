# This file is identical to implemented.txt, but contains
# notes on known bugs
exposure  # coloring/alpha is off
suns      
camera    # weird angle
lenses          
plane      
triangle   
barycentric # handle coords, for some reason only shows white
map        
bulb       
reflect         
refract         
rough           
antialias   # couldn't figure out the dark border thing
focus                  
